<?php
$config['Usermin'] = array(
    'sendEmailAfterUserCreated' => true,
    'emailFrom' => 'robot@domain.com',
    'emailFromName' => 'Usermin',
);