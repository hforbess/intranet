The .pot (template) file contains the translated strings
copy them to your existing .po file in
/app/locale/[language]/LC_MESSAGES/default.po

For some languages there might be already out of the box translations available.
If not, you can send them to me and I will add them.
Note: You have to rename to default.po, as well.

