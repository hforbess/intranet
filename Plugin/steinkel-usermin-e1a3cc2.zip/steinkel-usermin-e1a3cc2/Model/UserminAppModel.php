<?php
App::uses('AppModel', 'Model');
class UserminAppModel extends AppModel {

}

