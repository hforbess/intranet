<?php
App::uses('TimeLib', 'Tools.Utility');

/**
 * TODO: remove
 * @deprecated
 *
 * 2011-03-03 ms
 */
class DatetimeLib extends TimeLib {


}